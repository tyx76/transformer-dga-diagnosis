#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DEPRECATED: retained for legacy KB tooling only; the main retrieval route no longer calls search_knowledge_base() or merge_with_hybrid().
"""

from __future__ import annotations

import importlib
import logging
import os
import re
import sys
from typing import Any

from vector_kb.chunk_filter import is_body_text, query_overlap

LOGGER = logging.getLogger(__name__)


def _debug_enabled() -> bool:
    return "--debug" in sys.argv[1:]
# 支持的知识库后端。
_VALID_BACKENDS = ("pure_kb", "plant_kb")
# 默认使用 plant_kb；可通过 KB_BACKEND=pure_kb 回退旧库。
_REQUESTED_BACKEND = os.getenv("KB_BACKEND", "plant_kb").strip().lower()
_DOC_RE = re.compile(
    r"^(?P<doc_id>(?:DL/T|GB/T|GB|IEC)\s*\d+(?:\s*-\s*\d{4})?)",
    re.IGNORECASE,
)
_RESULT_FIELDS = ("doc_id", "clause", "title", "text", "page", "citation", "score", "citation_eligible", "is_body")

# The legacy pure_kb backend still exposes the old six-domain taxonomy.
# Translate the current router domains at the adapter boundary so the main
# pipeline can keep a single seven-domain contract.
_PURE_KB_DOMAINS = {"dga", "oil_temp", "safety", "equipment", "dp", "cases"}

_BACKEND_DOMAIN_ALIASES = {
    "pure_kb": {
        "transformer_dga": ("dga",),
        "auxiliary": ("oil_temp", "equipment"),
        "standards_safety": ("safety",),
        "fault_cases": ("cases",),
    },
}


def _load_backend(name: str):
    """导入指定后端；导入失败时回退到另一个可用后端。"""
    if name not in _VALID_BACKENDS:
        raise ValueError(
            f"KB_BACKEND={name!r} 无效，可选值为：{', '.join(_VALID_BACKENDS)}"
        )

    try:
        return importlib.import_module(name), name
    except Exception as exc:
        LOGGER.warning("知识库后端 %s 导入失败：%s", name, exc)
        fallback = "plant_kb" if name == "pure_kb" else "pure_kb"
        try:
            module = importlib.import_module(fallback)
            LOGGER.warning("已回退到知识库后端 %s", fallback)
            return module, fallback
        except Exception as fallback_exc:
            raise RuntimeError(
                f"知识库后端全部不可用：{name} 和 {fallback} 均导入失败"
            ) from fallback_exc


kb_backend = None
_BACKEND_NAME = _REQUESTED_BACKEND
_BACKEND_LOAD_ERROR: Exception | None = None


def _ensure_backend():
    """Load the configured member backend only when its API is actually used."""
    global kb_backend, _BACKEND_NAME, _BACKEND_LOAD_ERROR
    if kb_backend is not None:
        return kb_backend
    if _BACKEND_LOAD_ERROR is not None:
        return None
    try:
        kb_backend, _BACKEND_NAME = _load_backend(_REQUESTED_BACKEND)
        return kb_backend
    except Exception as exc:
        _BACKEND_LOAD_ERROR = exc
        return None


def get_backend_name() -> str:
    """返回实际加载成功的后端名称。"""
    return _BACKEND_NAME


def get_backend_stats() -> dict:
    """返回当前后端统计信息；读取失败时返回空字典。"""
    if kb_backend is None:
        return {}
    try:
        return dict(kb_backend.stats())
    except Exception:
        LOGGER.exception("读取知识库统计失败：backend=%s", _BACKEND_NAME)
        return {}


def _result_key(item: dict) -> tuple[str, str]:
    """Return the canonical deduplication key."""
    doc_id = str(item.get("doc_id") or "")
    clause = str(item.get("clause") or "")
    if doc_id or clause:
        return doc_id, clause
    return "CASE", str(item.get("citation") or item.get("title") or "")


def _parse_doc_id(citation: str) -> str | None:
    match = _DOC_RE.match(str(citation or "").strip())
    if not match:
        return None
    return re.sub(r"\s*-\s*", "-", match.group("doc_id")).strip()


def _normalize_score(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def adapt_chunk(raw: dict) -> dict | None:
    """Convert a backend result into the standard chunk format."""
    if not isinstance(raw, dict):
        return None

    domain = str(raw.get("domain") or raw.get("module") or "").strip()
    if domain == "dp":
        return None

    chunk_id = str(raw.get("chunk_id") or raw.get("id") or "").strip()
    doc_id = str(raw.get("doc_id") or raw.get("source_file") or "").strip() or None
    clause = str(raw.get("clause") or "").strip() or None
    citation = str(raw.get("citation") or "").strip()

    if doc_id is None and citation:
        doc_id = _parse_doc_id(citation)

    if domain == "cases":
        doc_id = f"CASE:{chunk_id}" if chunk_id else "CASE"
        clause = chunk_id or clause

    title = str(raw.get("title") or "").strip() or (clause or "")
    text = str(raw.get("text") or "").strip()
    page = raw.get("page")
    score = _normalize_score(raw.get("score", 0.0))

    citation_eligible = bool(doc_id and clause)
    is_body = is_body_text({"text": text, "title": title, "clause": clause or ""})
    return {
        "doc_id": doc_id,
        "clause": clause,
        "title": title,
        "text": text,
        "page": page,
        "citation": citation,
        "score": score,
        "citation_eligible": citation_eligible,
        "is_body": is_body,
    }


def _normalize_filters(filters: dict | None) -> dict:
    """Normalize single-item list filters to the scalar form used by KBs."""
    normalized = {}
    for key, value in (filters or {}).items():
        if isinstance(value, (list, tuple)):
            if len(value) == 1:
                normalized[key] = value[0]
        else:
            normalized[key] = value
    return normalized


def _dedupe_standard_chunks(chunks: list[dict], keep: int | None = None) -> list[dict]:
    best: dict[tuple[str, str], dict] = {}
    for chunk in chunks:
        if not isinstance(chunk, dict):
            continue
        key = _result_key(chunk)
        current = best.get(key)
        if current is None or _normalize_score(chunk.get("score")) > _normalize_score(current.get("score")):
            best[key] = chunk
    result = sorted(
        best.values(),
        key=lambda item: (1 if is_body_text(item) else 0, _normalize_score(item.get("score"))),
        reverse=True,
    )
    return result[:keep] if keep is not None else result


def _resolve_backend_domains(domains: list[str]) -> list[str]:
    """Translate router domains to the configured backend taxonomy."""
    aliases = _BACKEND_DOMAIN_ALIASES.get(_BACKEND_NAME, {})
    resolved: list[str] = []
    for domain in domains:
        for candidate in aliases.get(domain, (domain,)):
            if _BACKEND_NAME == "pure_kb" and candidate not in _PURE_KB_DOMAINS:
                continue
            if candidate and candidate not in resolved:
                resolved.append(candidate)
    return resolved


# DEPRECATED: main pipeline no longer calls this function. Use hybrid_retriever for retrieval.
def search_knowledge_base(question: str, route: dict, top_k: int = 20) -> list[dict]:
    """Call the configured backend with explicit domains and return chunks."""
    if not isinstance(route, dict):
        return []
    domains = _resolve_backend_domains(list(route.get("domains") or []))
    if not domains or route.get("mode") == "refuse":
        return []
    backend = _ensure_backend()
    if backend is None:
        return []
    filters = _normalize_filters(route.get("filters"))
    try:
        raw_results = backend.search(
            query=question,
            domains=domains,
            filters=filters or None,
            top_k=max(1, int(top_k)),
        )
    except Exception:
        LOGGER.exception("知识库检索失败：backend=%s", _BACKEND_NAME)
        return []

    chunks = []
    for raw in raw_results or []:
        chunk = adapt_chunk(raw)
        if chunk is not None:
            chunks.append(chunk)
    result = _dedupe_standard_chunks(chunks, keep=max(1, int(top_k)))
    eligible = sum(1 for chunk in result if chunk.get("citation_eligible"))
    if _debug_enabled():
        print(
            f"[引用资格] eligible={eligible} ineligible={len(result) - eligible}",
            flush=True,
        )
    return result


# DEPRECATED: legacy KB fusion helper retained only for deprecated APIs.
def _rrf_merge(
    hybrid_results: list[dict],
    kb_results: list[dict],
    top_k: int,
    k: int = 60,
    w_hybrid: float = 1.0,
    w_kb: float = 1.0,
    query: str | None = None,
) -> list[dict]:
    hybrid = _dedupe_standard_chunks([c for c in hybrid_results if isinstance(c, dict)])
    kb = _dedupe_standard_chunks([c for c in kb_results if isinstance(c, dict)])

    scores: dict[tuple[str, str], float] = {}
    documents: dict[tuple[str, str], dict] = {}

    for index, item in enumerate(hybrid, start=1):
        key = _result_key(item)
        body_weight = 1.0 if is_body_text(item) else 0.5
        scores[key] = scores.get(key, 0.0) + float(w_hybrid) * body_weight / (k + index)
        documents[key] = dict(item)

    for index, item in enumerate(kb, start=1):
        key = _result_key(item)
        body_weight = 1.0 if is_body_text(item) else 0.5
        scores[key] = scores.get(key, 0.0) + float(w_kb) * body_weight / (k + index)
        if key not in documents:
            documents[key] = dict(item)
        else:
            for field in _RESULT_FIELDS:
                if not documents[key].get(field) and item.get(field):
                    documents[key][field] = item[field]

    def rank_key(key: str) -> tuple[int, int, float]:
        item = documents[key]
        return (
            1 if is_body_text(item) else 0,
            query_overlap(item, query or ""),
            scores[key],
        )

    ranked = sorted(scores, key=rank_key, reverse=True)
    merged = []
    for key in ranked[:top_k]:
        item = dict(documents[key])
        item["score"] = round(scores[key], 6)
        if "citation_eligible" not in item:
            item["citation_eligible"] = bool(item.get("doc_id") and item.get("clause"))
        else:
            item["citation_eligible"] = bool(item.get("citation_eligible"))
        item["is_body"] = is_body_text(item)
        merged.append(item)
    return merged


# DEPRECATED: main pipeline no longer calls this function. Use chunk_filter.prioritize_results().
def merge_with_hybrid(
    hybrid_results: list[dict],
    kb_results: list[dict],
    top_k: int = 5,
    w_hybrid: float = 1.0,
    w_kb: float = 1.0,
    query: str | None = None,
) -> list[dict]:
    """Legacy hybrid + KB RRF fusion retained for old scripts."""
    if top_k <= 0:
        return []
    return _rrf_merge(
        hybrid_results or [],
        kb_results or [],
        int(top_k),
        k=60,
        w_hybrid=w_hybrid,
        w_kb=w_kb,
        query=query,
    )


__all__ = [
    "adapt_chunk",
    "search_knowledge_base",
    "merge_with_hybrid",
    "get_backend_name",
    "get_backend_stats",
]